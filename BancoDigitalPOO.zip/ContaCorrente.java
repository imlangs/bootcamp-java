public class ContaCorrente extends Conta {
    public ContaCorrente(String numeroConta) {
        super(numeroConta);
    }

    // Adicionar funcionalidades específicas da conta corrente, se houver
}
