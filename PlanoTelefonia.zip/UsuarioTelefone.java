import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UsuarioTelefone {
    private String nome;
    private String numero;
    private Plano plano;

    @Autowired
    private PlanoService planoService;

    public UsuarioTelefone() {
    }

    public UsuarioTelefone(String nome, String numero, Plano plano) {
        this.nome = nome;
        this.numero = numero;
        this.plano = plano;
    }

    public String fazerChamada(String destinatario, int duracaoMinutos) {
        double custoChamada = planoService.calcularCustoChamada(duracaoMinutos);
        if (planoService.verificarSaldoSuficiente(plano, custoChamada)) {
            planoService.deduzirSaldo(plano, custoChamada);
            return String.format("Chamada para %s realizada com sucesso. Saldo restante: $%.2f",
                    destinatario, plano.getSaldo());
        } else {
            return "Saldo insuficiente para realizar a chamada.";
        }
    }

    public String mensagemPersonalizada() {
        return planoService.mensagemPersonalizada(plano);
    }
}
