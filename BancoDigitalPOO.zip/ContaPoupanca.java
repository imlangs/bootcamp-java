public class ContaPoupanca extends Conta {
    public ContaPoupanca(String numeroConta) {
        super(numeroConta);
    }

    // Adicionar funcionalidades específicas da conta poupança, se houver
}
