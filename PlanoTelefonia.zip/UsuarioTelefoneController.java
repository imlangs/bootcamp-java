import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuario")
public class UsuarioTelefoneController {

    @Autowired
    private UsuarioTelefone usuarioTelefone;

    @PostMapping("/chamada")
    public String fazerChamada(@RequestParam String destinatario, @RequestParam int duracaoMinutos) {
        return usuarioTelefone.fazerChamada(destinatario, duracaoMinutos);
    }

    @GetMapping("/mensagem")
    public String mensagemPersonalizada() {
        return usuarioTelefone.mensagemPersonalizada();
    }
}
