import org.springframework.stereotype.Service;

@Service
public class PlanoService {
    public double calcularCustoChamada(int duracaoMinutos) {
        return duracaoMinutos * 0.10; // Custo de $0.10 por minuto
    }

    public boolean verificarSaldoSuficiente(Plano plano, double custoChamada) {
        return plano.getSaldo() >= custoChamada;
    }

    public void deduzirSaldo(Plano plano, double custoChamada) {
        double novoSaldo = plano.getSaldo() - custoChamada;
        plano.setSaldo(novoSaldo);
    }

    public String mensagemPersonalizada(Plano plano) {
        if (plano.getSaldo() < 10) {
            return "Seu saldo está baixo. Recarregue e use os serviços do seu plano.";
        } else if (plano.getSaldo() >= 50) {
            return "Parabéns! Continue aproveitando seu plano sem preocupações.";
        } else {
            return "Seu saldo está razoável. Aproveite o uso moderado do seu plano.";
        }
    }
}
